# Simple Weather App

This is a very basic application developed as an Angular tutorial. Follow the details at https://learnsomethingquick.com/build-a-weather-app-with-angular/.
